# 🚀 Deploy Platform Backend

Modern Node.js backend — Vercel deployment gateway, realtime WebSocket console, file manager, and project preview system.

---

## ⚡ Quick Start (Termux)

```bash
# 1. Install dependencies
bash install.sh

# 2. Start server
node server.js
```

---

## 📁 Project Structure

```
backend/
├── server.js              # Entry point
├── package.json
├── .env                   # Environment variables
├── config/index.js        # Centralized config
├── routes/                # Express routes
├── controllers/           # Business logic handlers
├── middleware/            # Auth, CORS, rate limit, error
├── services/              # Core service layer
├── websocket/             # WebSocket handler
├── utils/                 # Helpers & ASCII banner
├── database/              # JSON DB helpers
├── uploads/               # Temp ZIP uploads
├── projects/              # Extracted projects
├── logs/                  # Access/deploy/error logs
├── temp/                  # Temp files
└── public/                # Static public assets
```

---

## 🔌 API Endpoints

### Public
| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Dashboard & server status |
| POST | `/api/login` | Get JWT token |

### Protected (Bearer Token or x-api-key)
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/project/upload` | Upload ZIP project |
| GET | `/api/project/list` | List projects |
| GET | `/api/project/:name` | Project info |
| POST | `/api/deploy/vercel` | Deploy to Vercel |
| GET | `/api/deploy/` | List deployments |
| GET | `/api/deploy/:id` | Deployment details |
| POST | `/api/deploy/redeploy/:id` | Redeploy |
| DELETE | `/api/deploy/:id` | Delete deployment |
| GET | `/api/fs/list` | File manager list |
| GET | `/api/fs/read` | Read file content |
| DELETE | `/api/fs/remove` | Delete file/folder |
| GET | `/preview/:project` | HTML preview |

---

## 🔑 Authentication

**Login:**
```bash
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

**Use token:**
```bash
curl http://localhost:3000/api/deploy/ \
  -H "Authorization: Bearer <TOKEN>"
```

**Or API key:**
```bash
curl http://localhost:3000/api/deploy/ \
  -H "x-api-key: vcp_25wysQL27..."
```

---

## 📤 Upload & Deploy

```bash
# 1. Upload ZIP
curl -X POST http://localhost:3000/api/project/upload \
  -H "x-api-key: YOUR_KEY" \
  -F "file=@myproject.zip" \
  -F "name=my-site"

# 2. Deploy to Vercel
curl -X POST http://localhost:3000/api/deploy/vercel \
  -H "x-api-key: YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectFolder":"my-site_abc123"}'
```

---

## 🔌 WebSocket

Connect to `ws://localhost:3000/ws`

Events received:
- `connected` — handshake
- `deploy:start` — deploy initiated
- `deploy:uploading` — uploading files to Vercel
- `deploy:building` — Vercel is building
- `deploy:log` — realtime log line
- `deploy:ready` — deployment URL ready
- `deploy:error` — deployment failed

```js
const ws = new WebSocket('ws://localhost:3000/ws');
ws.onmessage = (e) => {
  const { event, data } = JSON.parse(e.data);
  console.log(event, data);
};
```

---

## ⚙️ Environment Variables

| Variable | Description |
|----------|-------------|
| `PORT` | Server port (default: 3000) |
| `JWT_SECRET` | JWT signing secret |
| `MASTER_API_KEY` | Master API key |
| `VERCEL_TOKEN` | Vercel API token |
| `ADMIN_USERNAME` | Admin login username |
| `ADMIN_PASSWORD` | Admin login password |
