import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT = join(__dirname, '..');

export const config = {
  port: parseInt(process.env.PORT) || 3000,
  jwtSecret: process.env.JWT_SECRET || 'fallback_secret_change_me',
  masterApiKey: process.env.MASTER_API_KEY,
  vercelToken: process.env.VERCEL_TOKEN,
  adminUsername: process.env.ADMIN_USERNAME || 'admin',
  adminPassword: process.env.ADMIN_PASSWORD || 'admin123',
  nodeEnv: process.env.NODE_ENV || 'development',

  paths: {
    root: ROOT,
    uploads: join(ROOT, 'uploads'),
    projects: join(ROOT, 'projects'),
    logs: join(ROOT, 'logs'),
    temp: join(ROOT, 'temp'),
    database: join(ROOT, 'database'),
    public: join(ROOT, 'public'),
  },

  vercel: {
    apiBase: 'https://api.vercel.com',
    token: process.env.VERCEL_TOKEN,
  },

  upload: {
    maxSize: 100 * 1024 * 1024, // 100MB
    allowedTypes: ['application/zip', 'application/x-zip-compressed'],
  },

  rateLimit: {
    windowMs: 15 * 60 * 1000,
    max: 200,
  },
};

export default config;
