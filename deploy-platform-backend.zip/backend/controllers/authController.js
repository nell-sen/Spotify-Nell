import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { config } from '../config/index.js';
import { ok, fail } from '../utils/response.js';

export async function login(req, res) {
  const { username, password, apiKey } = req.body || {};

  // API key login
  if (apiKey) {
    if (apiKey === config.masterApiKey) {
      const token = jwt.sign({ username: 'api', role: 'admin' }, config.jwtSecret, { expiresIn: '7d' });
      return ok(res, { token, expiresIn: '7d' }, 'Authenticated via API key');
    }
    return fail(res, 'Invalid API key', 401);
  }

  // Username/password login
  if (!username || !password) {
    return fail(res, 'username and password required', 400);
  }

  if (username !== config.adminUsername) {
    return fail(res, 'Invalid credentials', 401);
  }

  const valid = password === config.adminPassword;
  if (!valid) {
    return fail(res, 'Invalid credentials', 401);
  }

  const token = jwt.sign({ username, role: 'admin' }, config.jwtSecret, { expiresIn: '24h' });
  return ok(res, { token, expiresIn: '24h', username }, 'Login successful');
}

export const authController = { login };
export default authController;
