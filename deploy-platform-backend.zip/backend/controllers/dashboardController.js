import os from 'os';
import { ok } from '../utils/response.js';
import { getClientCount } from '../services/websocketService.js';
import { listDeployments } from '../services/deployService.js';
import { listProjects } from '../services/projectService.js';

export async function getDashboard(req, res) {
  const deployments = await listDeployments().catch(() => []);
  const projects = await listProjects().catch(() => []);
  const memUsed = process.memoryUsage();
  const cpus = os.cpus();

  const cpuLoad = cpus.map(cpu => {
    const total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
    const idle = cpu.times.idle;
    return Math.round(((total - idle) / total) * 100);
  });

  return ok(res, {
    server: {
      status: 'running',
      uptime: Math.round(process.uptime()),
      uptimeHuman: formatUptime(process.uptime()),
      pid: process.pid,
      nodeVersion: process.version,
      platform: os.platform(),
      arch: os.arch(),
    },
    websocket: {
      clients: getClientCount(),
    },
    deployments: {
      total: deployments.length,
      ready: deployments.filter(d => d.status === 'ready').length,
      error: deployments.filter(d => d.status === 'error').length,
      pending: deployments.filter(d => d.status === 'pending').length,
    },
    projects: {
      total: projects.length,
      list: projects.map(p => ({ name: p.name, framework: p.framework })),
    },
    memory: {
      heapUsed: Math.round(memUsed.heapUsed / 1024 / 1024),
      heapTotal: Math.round(memUsed.heapTotal / 1024 / 1024),
      rss: Math.round(memUsed.rss / 1024 / 1024),
      totalSystem: Math.round(os.totalmem() / 1024 / 1024),
      freeSystem: Math.round(os.freemem() / 1024 / 1024),
      unit: 'MB',
    },
    cpu: {
      model: cpus[0]?.model || 'unknown',
      cores: cpus.length,
      avgLoad: Math.round(cpuLoad.reduce((a, b) => a + b, 0) / cpuLoad.length),
    },
  }, 'Deploy Platform running');
}

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

export const dashboardController = { getDashboard };
export default dashboardController;
