import path from 'path';
import { ok, fail, serverError } from '../utils/response.js';
import { config } from '../config/index.js';
import {
  createDeployment,
  runVercelDeploy,
  listDeployments,
  getDeployment,
  removeDeployment,
} from '../services/deployService.js';
import {
  getVercelDeployment,
  deleteVercelDeployment,
  redeployVercel,
} from '../services/vercelService.js';

export async function deployVercel(req, res) {
  const { projectName, projectFolder } = req.body || {};

  if (!projectFolder && !projectName) {
    return fail(res, 'projectFolder or projectName is required', 400);
  }

  const folder = projectFolder || projectName;
  const projectDir = path.join(config.paths.projects, folder);

  // Create deployment record first
  const deployment = await createDeployment(folder, projectDir, 'vercel').catch(err => {
    return serverError(res, err, 'Failed to create deployment record');
  });
  if (!deployment || !deployment.id) return;

  // Respond immediately with deployment ID, run async
  res.setHeader('x-deployment-id', deployment.id);
  ok(res, { deploymentId: deployment.id, status: 'deploying', projectName: folder }, 'Deployment started');

  // Run in background
  runVercelDeploy(deployment.id, projectDir, folder).catch(err => {
    console.error('[DEPLOY] Background error:', err.message);
  });
}

export async function getDeployments(req, res) {
  try {
    const deployments = await listDeployments();
    return ok(res, { deployments, count: deployments.length }, 'Deployments listed');
  } catch (err) {
    return serverError(res, err);
  }
}

export async function getDeploymentById(req, res) {
  try {
    const deployment = await getDeployment(req.params.id);
    if (!deployment) return fail(res, 'Deployment not found', 404);

    // If we have a vercelId, fetch live status
    if (deployment.vercelId) {
      try {
        const live = await getVercelDeployment(deployment.vercelId);
        deployment.vercelStatus = live.readyState;
        deployment.vercelUrl = live.url ? `https://${live.url}` : deployment.url;
      } catch { /* offline */ }
    }

    return ok(res, deployment, 'Deployment details');
  } catch (err) {
    return serverError(res, err);
  }
}

export async function redeployById(req, res) {
  try {
    const deployment = await getDeployment(req.params.id);
    if (!deployment) return fail(res, 'Deployment not found', 404);

    // Create a new deployment record and re-run
    const newDeploy = await createDeployment(deployment.projectName, deployment.projectDir, 'vercel');
    res.setHeader('x-deployment-id', newDeploy.id);
    ok(res, { deploymentId: newDeploy.id, status: 'deploying' }, 'Redeploy started');

    runVercelDeploy(newDeploy.id, deployment.projectDir, deployment.projectName).catch(() => {});
  } catch (err) {
    return serverError(res, err);
  }
}

export async function deleteDeploymentById(req, res) {
  try {
    const deployment = await getDeployment(req.params.id);
    if (!deployment) return fail(res, 'Deployment not found', 404);

    if (deployment.vercelId) {
      await deleteVercelDeployment(deployment.vercelId).catch(() => {});
    }
    await removeDeployment(req.params.id);
    return ok(res, { id: req.params.id }, 'Deployment deleted');
  } catch (err) {
    return serverError(res, err);
  }
}

export const deployController = {
  deployVercel,
  getDeployments,
  getDeploymentById,
  redeployById,
  deleteDeploymentById,
};

export default deployController;
