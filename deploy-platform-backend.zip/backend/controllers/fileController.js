import path from 'path';
import { ok, fail, serverError } from '../utils/response.js';
import { config } from '../config/index.js';
import { listDirectory, readFile, removeFile } from '../services/fileService.js';

function getBase(scope) {
  if (scope === 'projects') return config.paths.projects;
  if (scope === 'uploads') return config.paths.uploads;
  if (scope === 'logs') return config.paths.logs;
  return config.paths.projects; // default
}

export async function listFiles(req, res) {
  const { scope = 'projects', path: relPath = '' } = req.query;
  const base = getBase(scope);

  try {
    const items = await listDirectory(base, relPath);
    return ok(res, { items, path: relPath, scope, count: items.length }, 'Directory listed');
  } catch (err) {
    if (err.message === 'Path traversal detected') return fail(res, err.message, 403);
    return serverError(res, err, 'Failed to list directory');
  }
}

export async function readFileContent(req, res) {
  const { scope = 'projects', path: relPath = '' } = req.query;
  if (!relPath) return fail(res, 'path query param required', 400);

  const base = getBase(scope);

  try {
    const result = await readFile(base, relPath);
    return ok(res, { ...result, path: relPath }, 'File content');
  } catch (err) {
    if (err.message === 'Path traversal detected') return fail(res, err.message, 403);
    if (err.message.includes('not previewable') || err.message.includes('too large')) {
      return fail(res, err.message, 415);
    }
    return serverError(res, err);
  }
}

export async function deleteFile(req, res) {
  const { scope = 'projects', path: relPath = '' } = req.query;
  if (!relPath) return fail(res, 'path query param required', 400);

  const base = getBase(scope);

  try {
    await removeFile(base, relPath);
    return ok(res, { path: relPath }, 'Deleted');
  } catch (err) {
    if (err.message === 'Path traversal detected') return fail(res, err.message, 403);
    return serverError(res, err);
  }
}

export const fileController = { listFiles, readFileContent, deleteFile };
export default fileController;
