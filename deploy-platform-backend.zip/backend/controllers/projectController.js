import fs from 'fs/promises';
import { ok, fail, serverError } from '../utils/response.js';
import { extractZip } from '../services/projectService.js';
import { listProjects, getProjectInfo } from '../services/projectService.js';

export async function uploadProject(req, res) {
  if (!req.file) return fail(res, 'No ZIP file uploaded', 400);

  const projectName = req.body.name || req.file.originalname.replace('.zip', '');

  try {
    const result = await extractZip(req.file.path, projectName);

    // clean up uploaded zip
    await fs.unlink(req.file.path).catch(() => {});

    return ok(res, {
      projectId: result.id,
      folderName: result.folderName,
      framework: result.framework,
      hasPackageJson: result.hasPackageJson,
      path: result.destDir,
    }, `Project uploaded and extracted. Framework: ${result.framework}`);
  } catch (err) {
    await fs.unlink(req.file?.path).catch(() => {});
    return serverError(res, err, 'Failed to extract project');
  }
}

export async function getProjects(req, res) {
  try {
    const projects = await listProjects();
    return ok(res, { projects, count: projects.length }, 'Projects listed');
  } catch (err) {
    return serverError(res, err, 'Failed to list projects');
  }
}

export async function getProject(req, res) {
  try {
    const info = await getProjectInfo(req.params.name);
    return ok(res, info, 'Project info');
  } catch (err) {
    return fail(res, 'Project not found', 404);
  }
}

export const projectController = { uploadProject, getProjects, getProject };
export default projectController;
