import fs from 'fs/promises';
import path from 'path';
import { config } from '../config/index.js';

function dbPath(name) {
  return path.join(config.paths.database, `${name}.json`);
}

export async function readJSON(name, fallback = []) {
  try {
    const raw = await fs.readFile(dbPath(name), 'utf-8');
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export async function writeJSON(name, data) {
  await fs.mkdir(config.paths.database, { recursive: true });
  await fs.writeFile(dbPath(name), JSON.stringify(data, null, 2), 'utf-8');
}

export async function appendJSON(name, item, fallback = []) {
  const existing = await readJSON(name, fallback);
  if (!Array.isArray(existing)) throw new Error(`DB "${name}" is not an array`);
  existing.push(item);
  await writeJSON(name, existing);
  return existing;
}

export async function updateJSON(name, predicate, updater, fallback = []) {
  const data = await readJSON(name, fallback);
  const mapped = data.map(item => predicate(item) ? { ...item, ...updater(item) } : item);
  await writeJSON(name, mapped);
  return mapped;
}

export async function deleteFromJSON(name, predicate, fallback = []) {
  const data = await readJSON(name, fallback);
  const filtered = data.filter(item => !predicate(item));
  await writeJSON(name, filtered);
  return filtered;
}
