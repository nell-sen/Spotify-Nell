#!/bin/bash
# ============================================================
# Deploy Platform — Termux Install Script
# ============================================================

echo ""
echo "🚀 Deploy Platform Backend — Installer"
echo "======================================="
echo ""

# Update packages
echo "→ Updating Termux packages..."
pkg update -y && pkg upgrade -y

# Install Node.js
echo "→ Installing Node.js..."
pkg install nodejs -y

# Verify
echo "→ Node: $(node -v)"
echo "→ NPM:  $(npm -v)"

# Install dependencies
echo "→ Installing npm dependencies..."
npm install

echo ""
echo "✅ Installation complete!"
echo ""
echo "   Start server:    node server.js"
echo "   Dashboard:       http://localhost:3000"
echo "   WebSocket:       ws://localhost:3000/ws"
echo ""
