import { config } from '../config/index.js';
import { fail } from '../utils/response.js';
import jwt from 'jsonwebtoken';

// Accepts either valid JWT Bearer token OR master API key
export function apiKeyMiddleware(req, res, next) {
  const apiKey = req.headers['x-api-key'];
  const authHeader = req.headers.authorization;

  if (apiKey && apiKey === config.masterApiKey) {
    req.user = { role: 'admin', via: 'api-key' };
    return next();
  }

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7);
    try {
      const decoded = jwt.verify(token, config.jwtSecret);
      req.user = decoded;
      return next();
    } catch { /* fall through */ }
  }

  return fail(res, 'Authentication required. Provide x-api-key or Bearer token.', 401);
}

export default apiKeyMiddleware;
