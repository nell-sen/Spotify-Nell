import cors from 'cors';

const corsOptions = {
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: [
    'Content-Type',
    'Authorization',
    'x-api-key',
    'x-requested-with',
    'Accept',
    'Origin',
  ],
  exposedHeaders: ['x-deployment-id'],
  credentials: false,
  optionsSuccessStatus: 200,
};

export const corsMiddleware = cors(corsOptions);
export const optionsHandler = cors(corsOptions);

export default corsMiddleware;
