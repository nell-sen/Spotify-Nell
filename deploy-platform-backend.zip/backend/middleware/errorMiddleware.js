import loggerService from '../services/loggerService.js';

export function errorMiddleware(err, req, res, next) {
  loggerService.error('express', err, { url: req.originalUrl, method: req.method });

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ success: false, message: 'File too large', data: {} });
  }
  if (err.message === 'Only ZIP files are allowed') {
    return res.status(415).json({ success: false, message: err.message, data: {} });
  }

  const status = err.status || err.statusCode || 500;
  res.status(status).json({
    success: false,
    message: err.message || 'Internal server error',
    data: {},
  });
}

export function notFoundMiddleware(req, res) {
  res.status(404).json({ success: false, message: `Route ${req.method} ${req.path} not found`, data: {} });
}

export default errorMiddleware;
