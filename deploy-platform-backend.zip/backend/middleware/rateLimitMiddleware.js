import rateLimit from 'express-rate-limit';
import { config } from '../config/index.js';

export const globalRateLimit = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests, slow down.', data: {} },
});

export const uploadRateLimit = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'Upload rate limit exceeded.', data: {} },
});

export const deployRateLimit = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  message: { success: false, message: 'Deploy rate limit exceeded. Wait 5 minutes.', data: {} },
});

export default globalRateLimit;
