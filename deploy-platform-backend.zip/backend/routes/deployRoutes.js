import { Router } from 'express';
import {
  deployVercel,
  getDeployments,
  getDeploymentById,
  redeployById,
  deleteDeploymentById,
} from '../controllers/deployController.js';
import apiKeyMiddleware from '../middleware/apiKeyMiddleware.js';
import { deployRateLimit } from '../middleware/rateLimitMiddleware.js';

const router = Router();

router.post('/vercel', apiKeyMiddleware, deployRateLimit, deployVercel);
router.get('/', apiKeyMiddleware, getDeployments);
router.get('/:id', apiKeyMiddleware, getDeploymentById);
router.post('/redeploy/:id', apiKeyMiddleware, deployRateLimit, redeployById);
router.delete('/:id', apiKeyMiddleware, deleteDeploymentById);

export default router;
