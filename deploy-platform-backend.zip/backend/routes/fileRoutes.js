import { Router } from 'express';
import { listFiles, readFileContent, deleteFile } from '../controllers/fileController.js';
import apiKeyMiddleware from '../middleware/apiKeyMiddleware.js';

const router = Router();

router.get('/list', apiKeyMiddleware, listFiles);
router.get('/read', apiKeyMiddleware, readFileContent);
router.delete('/remove', apiKeyMiddleware, deleteFile);

export default router;
