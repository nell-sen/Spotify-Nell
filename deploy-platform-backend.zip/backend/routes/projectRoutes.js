import { Router } from 'express';
import { uploadProject, getProjects, getProject } from '../controllers/projectController.js';
import { uploadMiddleware } from '../services/uploadService.js';
import apiKeyMiddleware from '../middleware/apiKeyMiddleware.js';
import { uploadRateLimit } from '../middleware/rateLimitMiddleware.js';

const router = Router();

router.post('/upload', apiKeyMiddleware, uploadRateLimit, uploadMiddleware.single('file'), uploadProject);
router.get('/list', apiKeyMiddleware, getProjects);
router.get('/:name', apiKeyMiddleware, getProject);

export default router;
