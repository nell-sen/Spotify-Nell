import 'dotenv/config';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import compression from 'compression';
import helmet from 'helmet';
import morgan from 'morgan';
import fs from 'fs/promises';

import { config } from './config/index.js';
import { initDirectories } from './utils/initDirs.js';
import { printStartupBanner } from './utils/ascii.js';

// Middleware
import { corsMiddleware, optionsHandler } from './middleware/corsMiddleware.js';
import { globalRateLimit } from './middleware/rateLimitMiddleware.js';
import { errorMiddleware, notFoundMiddleware } from './middleware/errorMiddleware.js';

// Routes
import dashboardRoutes from './routes/dashboardRoutes.js';
import authRoutes from './routes/authRoutes.js';
import projectRoutes from './routes/projectRoutes.js';
import deployRoutes from './routes/deployRoutes.js';
import fileRoutes from './routes/fileRoutes.js';

// WebSocket
import { initWebSocket } from './websocket/wsHandler.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function bootstrap() {
  // ─── Auto-create directories ────────────────────────────────
  await initDirectories();

  // ─── Express app ────────────────────────────────────────────
  const app = express();

  // Security
  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
  }));
  app.disable('x-powered-by');

  // CORS — allow all origins
  app.use(corsMiddleware);
  app.options('*', optionsHandler);

  // Compression & parsing
  app.use(compression());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Logging
  app.use(morgan('[:date[iso]] :method :url :status :response-time ms'));

  // Global rate limit
  app.use(globalRateLimit);

  // ─── Static public ──────────────────────────────────────────
  app.use('/public', express.static(config.paths.public));

  // ─── Preview system ─────────────────────────────────────────
  app.get('/preview/:project', async (req, res) => {
    const projectName = req.params.project.replace(/\.\./g, '');
    const indexPath = path.join(config.paths.projects, projectName, 'index.html');
    try {
      await fs.access(indexPath);
      res.sendFile(indexPath);
    } catch {
      res.status(404).send(`
        <!DOCTYPE html><html><head><meta charset="utf-8">
        <title>Preview Not Found</title>
        <style>body{font-family:monospace;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#0a0a0a;color:#fff}
        .box{text-align:center}.title{font-size:2rem;color:#ff4444;margin-bottom:1rem}.sub{color:#888}</style>
        </head><body><div class="box">
        <div class="title">404 — Preview Not Found</div>
        <div class="sub">Project <code>${projectName}</code> has no index.html</div>
        </body></html>`);
    }
  });

  // Project static file serving
  app.use('/projects', express.static(config.paths.projects));

  // ─── API Routes ─────────────────────────────────────────────
  app.use('/', dashboardRoutes);
  app.use('/api', authRoutes);
  app.use('/api/project', projectRoutes);
  app.use('/api/deploy', deployRoutes);
  app.use('/api/deployments', (req, res, next) => {
    // alias: GET /api/deployments → deployRoutes GET /
    req.url = req.url === '/' ? '/' : req.url;
    next();
  });
  app.use('/api/fs', fileRoutes);

  // ─── Error handling ─────────────────────────────────────────
  app.use(notFoundMiddleware);
  app.use(errorMiddleware);

  // ─── HTTP + WS Server ───────────────────────────────────────
  const server = http.createServer(app);
  initWebSocket(server);

  server.listen(config.port, '0.0.0.0', () => {
    printStartupBanner(config.port);
  });

  // ─── Graceful shutdown ──────────────────────────────────────
  process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
  process.on('SIGINT', () => { server.close(() => process.exit(0)); });
  process.on('uncaughtException', (err) => {
    console.error('[FATAL] Uncaught Exception:', err);
  });
  process.on('unhandledRejection', (reason) => {
    console.error('[FATAL] Unhandled Rejection:', reason);
  });
}

bootstrap().catch(err => {
  console.error('[STARTUP ERROR]', err);
  process.exit(1);
});
