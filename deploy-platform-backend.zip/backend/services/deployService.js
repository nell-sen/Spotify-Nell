import crypto from 'crypto';
import { readJSON, writeJSON, appendJSON, updateJSON, deleteFromJSON } from '../database/jsonDb.js';
import { deployToVercel } from './vercelService.js';
import loggerService from './loggerService.js';

const DB = 'deployments';

export async function createDeployment(projectName, projectDir, source = 'vercel') {
  const id = crypto.randomBytes(10).toString('hex');
  const record = {
    id,
    projectName,
    projectDir,
    source,
    status: 'pending',
    url: null,
    vercelId: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    logs: [],
  };

  await appendJSON(DB, record);
  loggerService.deployment(id, 'created', { projectName, source });
  return record;
}

export async function runVercelDeploy(deploymentId, projectDir, projectName) {
  await updateDeploymentStatus(deploymentId, 'deploying');

  try {
    const result = await deployToVercel(projectDir, projectName, deploymentId);
    await updateJSON(
      DB,
      d => d.id === deploymentId,
      () => ({
        status: result.success ? 'ready' : 'error',
        url: result.url,
        vercelId: result.vercelId,
        updatedAt: new Date().toISOString(),
      })
    );
    loggerService.deployment(deploymentId, result.success ? 'ready' : 'error', { url: result.url });
    return result;
  } catch (err) {
    await updateDeploymentStatus(deploymentId, 'error');
    loggerService.error('deployService.runVercelDeploy', err, { deploymentId });
    throw err;
  }
}

export async function updateDeploymentStatus(id, status) {
  await updateJSON(DB, d => d.id === id, () => ({ status, updatedAt: new Date().toISOString() }));
}

export async function listDeployments() {
  const all = await readJSON(DB, []);
  return all.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export async function getDeployment(id) {
  const all = await readJSON(DB, []);
  return all.find(d => d.id === id) || null;
}

export async function removeDeployment(id) {
  return deleteFromJSON(DB, d => d.id === id);
}

export const deployService = {
  createDeployment,
  runVercelDeploy,
  updateDeploymentStatus,
  listDeployments,
  getDeployment,
  removeDeployment,
};

export default deployService;
