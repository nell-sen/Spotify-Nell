import fs from 'fs/promises';
import path from 'path';
import { config } from '../config/index.js';

const TEXT_EXTS = new Set([
  '.js', '.mjs', '.cjs', '.ts', '.jsx', '.tsx',
  '.json', '.html', '.htm', '.css', '.scss', '.less',
  '.md', '.txt', '.env', '.yaml', '.yml', '.toml',
  '.sh', '.bash', '.xml', '.svg', '.vue',
]);

function safePath(base, rel) {
  const resolved = path.resolve(base, rel);
  if (!resolved.startsWith(path.resolve(base))) {
    throw new Error('Path traversal detected');
  }
  return resolved;
}

export async function listDirectory(base, rel = '') {
  const target = safePath(base, rel);
  const entries = await fs.readdir(target, { withFileTypes: true });

  const items = await Promise.all(entries.map(async (e) => {
    const full = path.join(target, e.name);
    const stat = await fs.stat(full).catch(() => null);
    const ext = path.extname(e.name).toLowerCase();
    return {
      name: e.name,
      type: e.isDirectory() ? 'directory' : 'file',
      size: stat?.size || 0,
      modified: stat?.mtime || null,
      ext: e.isDirectory() ? null : ext,
      isText: TEXT_EXTS.has(ext),
    };
  }));

  return items.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
}

export async function readFile(base, rel) {
  const target = safePath(base, rel);
  const stat = await fs.stat(target);
  const ext = path.extname(target).toLowerCase();

  if (!TEXT_EXTS.has(ext)) throw new Error('File type not previewable');
  if (stat.size > 512 * 1024) throw new Error('File too large to preview (>512KB)');

  const content = await fs.readFile(target, 'utf-8');
  return { content, size: stat.size, ext, modified: stat.mtime };
}

export async function removeFile(base, rel) {
  const target = safePath(base, rel);
  const stat = await fs.stat(target);
  if (stat.isDirectory()) {
    await fs.rm(target, { recursive: true, force: true });
  } else {
    await fs.unlink(target);
  }
}

export const fileService = { listDirectory, readFile, removeFile, safePath };
export default fileService;
