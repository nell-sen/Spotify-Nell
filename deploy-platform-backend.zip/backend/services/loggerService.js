import fs from 'fs/promises';
import path from 'path';
import { config } from '../config/index.js';

async function write(filename, entry) {
  try {
    await fs.mkdir(config.paths.logs, { recursive: true });
    const line = JSON.stringify({ ts: new Date().toISOString(), ...entry }) + '\n';
    await fs.appendFile(path.join(config.paths.logs, filename), line, 'utf-8');
  } catch { /* non-fatal */ }
}

export const loggerService = {
  access: (req, statusCode) => write('access.log', {
    method: req.method,
    url: req.originalUrl,
    ip: req.ip,
    status: statusCode,
  }),
  deployment: (deploymentId, event, detail = {}) => write('deployment.log', {
    deploymentId,
    event,
    ...detail,
  }),
  error: (source, err, extra = {}) => write('error.log', {
    source,
    message: err?.message || String(err),
    stack: err?.stack,
    ...extra,
  }),
};

export default loggerService;
