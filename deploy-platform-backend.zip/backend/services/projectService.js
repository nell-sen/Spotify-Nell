import AdmZip from 'adm-zip';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { config } from '../config/index.js';

const FRAMEWORKS = [
  { name: 'nextjs', detect: ['next.config.js', 'next.config.mjs', 'next.config.ts'] },
  { name: 'vite', detect: ['vite.config.js', 'vite.config.ts'] },
  { name: 'react', detect: ['src/App.jsx', 'src/App.tsx', 'src/App.js'] },
  { name: 'express', detect: ['server.js', 'app.js', 'index.js'] },
  { name: 'html', detect: ['index.html'] },
];

export async function extractZip(zipPath, projectName) {
  const id = crypto.randomBytes(6).toString('hex');
  const safeBase = (projectName || 'project')
    .replace(/[^a-zA-Z0-9-_]/g, '-')
    .slice(0, 40);
  const folderName = `${safeBase}_${id}`;
  const destDir = path.join(config.paths.projects, folderName);

  await fs.mkdir(destDir, { recursive: true });

  const zip = new AdmZip(zipPath);
  zip.extractAllTo(destDir, true);

  // Flatten single root directory if present
  const entries = await fs.readdir(destDir, { withFileTypes: true });
  if (entries.length === 1 && entries[0].isDirectory()) {
    const innerDir = path.join(destDir, entries[0].name);
    const innerEntries = await fs.readdir(innerDir);
    for (const item of innerEntries) {
      await fs.rename(path.join(innerDir, item), path.join(destDir, item)).catch(() => {});
    }
    await fs.rmdir(innerDir).catch(() => {});
  }

  const framework = await detectFramework(destDir);
  const hasPackageJson = await fileExists(path.join(destDir, 'package.json'));

  return {
    id,
    folderName,
    destDir,
    framework,
    hasPackageJson,
  };
}

async function detectFramework(dir) {
  const files = await flatFileList(dir);
  for (const fw of FRAMEWORKS) {
    for (const marker of fw.detect) {
      if (files.some(f => f.endsWith(marker.replace(/\//g, path.sep)))) {
        return fw.name;
      }
    }
  }
  return 'unknown';
}

async function flatFileList(dir, base = dir, result = []) {
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
      if (e.isDirectory()) await flatFileList(full, base, result);
      else result.push(full);
    }
  } catch { /* ignore */ }
  return result;
}

async function fileExists(p) {
  try { await fs.access(p); return true; } catch { return false; }
}

export async function listProjects() {
  try {
    const entries = await fs.readdir(config.paths.projects, { withFileTypes: true });
    const projects = [];
    for (const e of entries) {
      if (!e.isDirectory()) continue;
      const stat = await fs.stat(path.join(config.paths.projects, e.name));
      const framework = await detectFramework(path.join(config.paths.projects, e.name));
      projects.push({
        name: e.name,
        path: path.join(config.paths.projects, e.name),
        framework,
        created: stat.birthtime,
        modified: stat.mtime,
      });
    }
    return projects;
  } catch {
    return [];
  }
}

export async function getProjectInfo(projectName) {
  const projectDir = path.join(config.paths.projects, projectName);
  const stat = await fs.stat(projectDir);
  const framework = await detectFramework(projectDir);
  const hasPackageJson = await fileExists(path.join(projectDir, 'package.json'));
  let packageJson = null;
  if (hasPackageJson) {
    try {
      const raw = await fs.readFile(path.join(projectDir, 'package.json'), 'utf-8');
      packageJson = JSON.parse(raw);
    } catch { /* ignore */ }
  }
  return { name: projectName, framework, hasPackageJson, packageJson, stat };
}

export const projectService = { extractZip, listProjects, getProjectInfo };
export default projectService;
