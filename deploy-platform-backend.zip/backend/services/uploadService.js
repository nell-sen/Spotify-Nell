import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import { config } from '../config/index.js';

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.paths.uploads),
  filename: (req, file, cb) => {
    const uid = crypto.randomBytes(8).toString('hex');
    const ext = path.extname(file.originalname) || '.zip';
    cb(null, `upload_${uid}${ext}`);
  },
});

const fileFilter = (req, file, cb) => {
  const allowed = [
    'application/zip',
    'application/x-zip-compressed',
    'application/x-zip',
    'application/octet-stream',
  ];
  if (allowed.includes(file.mimetype) || file.originalname.endsWith('.zip')) {
    cb(null, true);
  } else {
    cb(new Error('Only ZIP files are allowed'), false);
  }
};

export const uploadMiddleware = multer({
  storage,
  fileFilter,
  limits: { fileSize: config.upload.maxSize },
});

export default uploadMiddleware;
