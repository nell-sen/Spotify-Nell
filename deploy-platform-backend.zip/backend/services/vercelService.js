import axios from 'axios';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { config } from '../config/index.js';
import { broadcast } from './websocketService.js';
import loggerService from './loggerService.js';

const api = axios.create({
  baseURL: config.vercel.apiBase,
  headers: {
    Authorization: `Bearer ${config.vercel.token}`,
    'Content-Type': 'application/json',
  },
  timeout: 60000,
});

async function collectFiles(dir, baseDir = dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relative = path.relative(baseDir, fullPath).replace(/\\/g, '/');

    // skip node_modules, .git, hidden
    if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;

    if (entry.isDirectory()) {
      const sub = await collectFiles(fullPath, baseDir);
      files.push(...sub);
    } else {
      const content = await fs.readFile(fullPath);
      files.push({
        file: relative,
        data: content.toString('base64'),
        encoding: 'base64',
      });
    }
  }

  return files;
}

export async function deployToVercel(projectDir, projectName, deploymentId) {
  const log = (msg, level = 'info') => {
    broadcast('deploy:log', { deploymentId, message: msg, level });
    loggerService.deployment(deploymentId, 'log', { message: msg, level });
  };

  try {
    log('📦 Collecting project files...');
    broadcast('deploy:start', { deploymentId, projectName });

    const files = await collectFiles(projectDir);
    log(`✔ Found ${files.length} file(s)`, 'success');

    // Sanitize project name for Vercel
    const sanitizedName = projectName
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-')
      .slice(0, 50);

    log('📤 Uploading to Vercel API...');
    broadcast('deploy:uploading', { deploymentId });

    const payload = {
      name: sanitizedName,
      files,
      projectSettings: {
        framework: null,
      },
      target: 'production',
    };

    const { data: deployment } = await api.post('/v13/deployments', payload);

    log(`🏗  Deployment created: ${deployment.id}`, 'success');
    broadcast('deploy:building', { deploymentId, vercelId: deployment.id });

    // Poll deployment status
    const vercelDeploymentId = deployment.id;
    let status = deployment.readyState || 'BUILDING';
    let url = deployment.url ? `https://${deployment.url}` : null;
    let attempts = 0;
    const maxAttempts = 60;

    while (!['READY', 'ERROR', 'CANCELED'].includes(status) && attempts < maxAttempts) {
      await new Promise(r => setTimeout(r, 3000));
      attempts++;

      try {
        const { data: statusData } = await api.get(`/v13/deployments/${vercelDeploymentId}`);
        status = statusData.readyState;
        url = statusData.url ? `https://${statusData.url}` : url;

        log(`⏳ Status: ${status} (${attempts * 3}s elapsed)`);

        // Fetch build logs
        try {
          const { data: logsData } = await api.get(`/v2/deployments/${vercelDeploymentId}/events`);
          const events = logsData || [];
          const recent = events.slice(-3);
          for (const evt of recent) {
            if (evt.text) log(`  › ${evt.text.trim()}`);
          }
        } catch { /* logs may not be available yet */ }

      } catch (pollErr) {
        log(`⚠ Poll error: ${pollErr.message}`, 'warn');
      }
    }

    if (status === 'READY') {
      log(`✅ Deployment READY → ${url}`, 'success');
      broadcast('deploy:ready', { deploymentId, vercelId: vercelDeploymentId, url, status });
      return { success: true, url, vercelId: vercelDeploymentId, status };
    } else {
      log(`❌ Deployment ended with status: ${status}`, 'error');
      broadcast('deploy:error', { deploymentId, vercelId: vercelDeploymentId, status });
      return { success: false, url, vercelId: vercelDeploymentId, status, error: `Status: ${status}` };
    }

  } catch (err) {
    const errMsg = err?.response?.data?.error?.message || err.message;
    log(`❌ Deploy failed: ${errMsg}`, 'error');
    broadcast('deploy:error', { deploymentId, error: errMsg });
    loggerService.error('vercelService.deployToVercel', err, { deploymentId });
    throw new Error(errMsg);
  }
}

export async function listVercelDeployments(limit = 20) {
  const { data } = await api.get(`/v6/deployments?limit=${limit}`);
  return data.deployments || [];
}

export async function getVercelDeployment(vercelId) {
  const { data } = await api.get(`/v13/deployments/${vercelId}`);
  return data;
}

export async function cancelVercelDeployment(vercelId) {
  const { data } = await api.patch(`/v12/deployments/${vercelId}/cancel`);
  return data;
}

export async function deleteVercelDeployment(vercelId) {
  const { data } = await api.delete(`/v13/deployments/${vercelId}`);
  return data;
}

export async function redeployVercel(vercelId) {
  const { data } = await api.post(`/v13/deployments?forceNew=1`, {
    deploymentId: vercelId,
    target: 'production',
  });
  return data;
}

export const vercelService = {
  deployToVercel,
  listVercelDeployments,
  getVercelDeployment,
  cancelVercelDeployment,
  deleteVercelDeployment,
  redeployVercel,
};

export default vercelService;
