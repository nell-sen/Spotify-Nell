import { WebSocketServer } from 'ws';

let wss = null;
const clients = new Set();

export function initWebSocket(server) {
  wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    clients.add(ws);
    console.log(`[WS] Client connected. Total: ${clients.size}`);

    ws.send(JSON.stringify({
      event: 'connected',
      data: { message: 'Connected to Deploy Platform WebSocket', clients: clients.size },
    }));

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.event === 'ping') {
          ws.send(JSON.stringify({ event: 'pong', data: { ts: Date.now() } }));
        }
      } catch { /* ignore malformed */ }
    });

    ws.on('close', () => {
      clients.delete(ws);
      console.log(`[WS] Client disconnected. Total: ${clients.size}`);
    });

    ws.on('error', (err) => {
      clients.delete(ws);
      console.error('[WS] Client error:', err.message);
    });
  });

  return wss;
}

export function broadcast(event, data = {}) {
  if (!wss) return;
  const payload = JSON.stringify({ event, data, ts: new Date().toISOString() });
  for (const client of clients) {
    if (client.readyState === 1) {
      try { client.send(payload); } catch { /* skip dead clients */ }
    }
  }
}

export function broadcastDeployLog(deploymentId, message, level = 'info') {
  broadcast('deploy:log', { deploymentId, message, level });
}

export function getClientCount() {
  return clients.size;
}

export const websocketService = { initWebSocket, broadcast, broadcastDeployLog, getClientCount };
export default websocketService;
