import os from 'os';
import { config } from '../config/index.js';

const RESET = '\x1b[0m';
const CYAN = '\x1b[36m';
const GREEN = '\x1b[32m';
const YELLOW = '\x1b[33m';
const MAGENTA = '\x1b[35m';
const BOLD = '\x1b[1m';
const DIM = '\x1b[2m';
const WHITE = '\x1b[97m';

export function printStartupBanner(wsPort) {
  const art = `
${CYAN}${BOLD}
 ██████╗ ███████╗██████╗ ██╗      ██████╗ ██╗   ██╗
 ██╔══██╗██╔════╝██╔══██╗██║     ██╔═══██╗╚██╗ ██╔╝
 ██║  ██║█████╗  ██████╔╝██║     ██║   ██║ ╚████╔╝ 
 ██║  ██║██╔══╝  ██╔═══╝ ██║     ██║   ██║  ╚██╔╝  
 ██████╔╝███████╗██║     ███████╗╚██████╔╝   ██║   
 ╚═════╝ ╚══════╝╚═╝     ╚══════╝ ╚═════╝    ╚═╝   
${RESET}${MAGENTA}${BOLD} ██████╗ ██╗      █████╗ ████████╗███████╗ ██████╗ ██████╗ ███╗   ███╗${RESET}
${MAGENTA}${BOLD}██╔══██╗██║     ██╔══██╗╚══██╔══╝██╔════╝██╔═══██╗██╔══██╗████╗ ████║${RESET}
${MAGENTA}${BOLD}██████╔╝██║     ███████║   ██║   █████╗  ██║   ██║██████╔╝██╔████╔██║${RESET}
${MAGENTA}${BOLD}██╔═══╝ ██║     ██╔══██║   ██║   ██╔══╝  ██║   ██║██╔══██╗██║╚██╔╝██║${RESET}
${MAGENTA}${BOLD}██║     ███████╗██║  ██║   ██║   ██║     ╚██████╔╝██║  ██║██║ ╚═╝ ██║${RESET}
${MAGENTA}${BOLD}╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝${RESET}
`;

  console.log(art);
  console.log(`${CYAN}${'─'.repeat(60)}${RESET}`);
  console.log(`${WHITE}${BOLD}  🚀 DEPLOY PLATFORM BACKEND${RESET}  ${DIM}v1.0.0 — Modern Modular Architecture${RESET}`);
  console.log(`${CYAN}${'─'.repeat(60)}${RESET}`);
  console.log(`${GREEN}  ✔ HTTP Server      ${RESET}→  ${YELLOW}http://localhost:${config.port}${RESET}`);
  console.log(`${GREEN}  ✔ WebSocket        ${RESET}→  ${YELLOW}ws://localhost:${config.port}${RESET}`);
  console.log(`${GREEN}  ✔ Vercel Gateway   ${RESET}→  ${YELLOW}${config.vercel.apiBase}${RESET}`);
  console.log(`${GREEN}  ✔ Vercel Token     ${RESET}→  ${YELLOW}${config.vercelToken ? config.vercelToken.slice(0, 12) + '...' : 'NOT SET'}${RESET}`);
  console.log(`${CYAN}${'─'.repeat(60)}${RESET}`);
  console.log(`${WHITE}  📁 Routes Active:${RESET}`);
  console.log(`${DIM}     GET  /                  → Dashboard${RESET}`);
  console.log(`${DIM}     POST /api/login          → Auth${RESET}`);
  console.log(`${DIM}     POST /api/project/upload → Upload ZIP${RESET}`);
  console.log(`${DIM}     POST /api/deploy/vercel  → Deploy to Vercel${RESET}`);
  console.log(`${DIM}     GET  /api/deployments    → List Deployments${RESET}`);
  console.log(`${DIM}     GET  /api/fs/list        → File Manager${RESET}`);
  console.log(`${DIM}     GET  /preview/:project   → Preview${RESET}`);
  console.log(`${CYAN}${'─'.repeat(60)}${RESET}`);
  console.log(`${WHITE}  🖥  System:${RESET}`);
  console.log(`${DIM}     OS: ${os.type()} ${os.release()} | CPU: ${os.cpus().length} cores | RAM: ${Math.round(os.totalmem() / 1024 / 1024)}MB${RESET}`);
  console.log(`${DIM}     Node: ${process.version} | PID: ${process.pid} | ENV: ${config.nodeEnv}${RESET}`);
  console.log(`${CYAN}${'─'.repeat(60)}${RESET}\n`);
}
