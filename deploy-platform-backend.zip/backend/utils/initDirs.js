import fs from 'fs/promises';
import { config } from '../config/index.js';

export async function initDirectories() {
  const dirs = Object.values(config.paths).filter(p => p !== config.paths.root);

  for (const dir of dirs) {
    try {
      await fs.mkdir(dir, { recursive: true });
    } catch {
      // already exists
    }
  }
}

export default initDirectories;
