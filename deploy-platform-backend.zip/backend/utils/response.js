export const ok = (res, data = {}, message = 'OK', statusCode = 200) => {
  return res.status(statusCode).json({ success: true, message, data });
};

export const fail = (res, message = 'Error', statusCode = 400, data = {}) => {
  return res.status(statusCode).json({ success: false, message, data });
};

export const serverError = (res, err, message = 'Internal server error') => {
  console.error('[ERROR]', err?.message || err);
  return res.status(500).json({
    success: false,
    message,
    data: { error: err?.message || String(err) },
  });
};
