// WebSocket handler module - initializes and manages WS connections
// Core logic lives in services/websocketService.js
// This module wires the WS server to the HTTP server

export { initWebSocket, broadcast, broadcastDeployLog, getClientCount } from '../services/websocketService.js';
